package com.example.samplebindservice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private MyService myService;
    private boolean isService = false;
    private TextView textView;

    // ServiceConnection 변수 생성

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
    }

    // bindService
    public void startService(View view) {
    }

    // unbindService
    public void stopService(View view) {
    }

    // getNumber
    public void getData(View view) {
    }

    // SecondActivity 실행
    public void goSecond(View view) {
    }
}
