package com.example.samplebindservice;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class MyService extends Service {
    // LocalBinder를 사용하는 IBinder 변수 생성

    private int number;
    private String TAG = "Service";

    public MyService() {
    }

    // LocalBinder 생성

    // return 값 변경
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    // onCreate 생성
    // number 0으로 초기화
    // Log 추가


    // getNumber 생성
}
